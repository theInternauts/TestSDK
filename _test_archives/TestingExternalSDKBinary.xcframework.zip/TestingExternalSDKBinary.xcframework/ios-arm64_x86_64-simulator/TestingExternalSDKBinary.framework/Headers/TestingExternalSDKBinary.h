//
//  TestingExternalSDKBinary.h
//  TestingExternalSDKBinary
//
//  Created by Cricket on 8/5/24.
//

#import <Foundation/Foundation.h>

//! Project version number for TestingExternalSDKBinary.
FOUNDATION_EXPORT double TestingExternalSDKBinaryVersionNumber;

//! Project version string for TestingExternalSDKBinary.
FOUNDATION_EXPORT const unsigned char TestingExternalSDKBinaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestingExternalSDKBinary/PublicHeader.h>


